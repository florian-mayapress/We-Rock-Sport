<?php
/**
 * fallback search template
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
